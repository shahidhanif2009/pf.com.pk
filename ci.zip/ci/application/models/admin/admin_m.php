<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
   class admin_m extends CI_Model
    {
      function __construct()
        {
         parent::__construct();
        }   
        function insert_data()
        {
        $name=$this->input->post('name');
        $email=$this->input->post('email');
        $password=$this->input->post('password');
        $mobile=$this->input->post('mobile');
               $this->db->select('*');
               $this->db->from('signup');
               $this->db->where('email',$email);
               $query=$this->db->get();
               if ($query->num_rows() > 0)
               {
                 return true;
               } 
             $data=array('name'=>$name,
                         'email'=>$email, 
                         'password'=>$password, 
                         'mobile'=>$mobile  
                         );
	     $this->db->insert('signup',$data);    
        }
	  function get_data()
    {
       $this->db->select('*');
        $this->db->from('signup');
        $query = $this->db->get();
        return $result = $query->result();
    }
	   }
                
