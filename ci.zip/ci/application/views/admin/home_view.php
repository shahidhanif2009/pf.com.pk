<html>
    <link href="http://www.discussdesk.com/view/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">

	
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<h2 align="center">Signup Users Home Panel</h2>
<h4 align="center">Welcome! you have successfully registerd</h4>
 <form>
	<div class="table-responsive" >
    <table border="0" align="center" class="table" style="border:1px solid #333;"> 
        
        <tbody>
       <tr>
       <th>#</th>
       <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        </tr>
        </tbody>  
           
    <?php
$i=1;
foreach($ResAre as $row)
    {   ?>
         <tr>
    <td><?php echo $i;?></td>
        <td><?php echo $row->name;?></td>
     <td><?php echo $row->email;?></td>
         <td><?php echo $row->mobile;?></td>
         </tr>
   <?php  $i++;} ?>
 <td colspan="6">
  </table>
  </div>
  </form>
</div>
<div class="col-md-3"></div>
	</div>
    
</html>
